import React from 'react'

export default function Benefits() {
	return (
		<div className='w-[100wh] h-[30px] lg:h-[50px] text-[30px] bg-[#E1A421]'></div>
	)
}
